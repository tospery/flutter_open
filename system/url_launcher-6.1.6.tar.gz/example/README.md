# url_launcher_example

Demonstrates how to use the url_launcher plugin.
